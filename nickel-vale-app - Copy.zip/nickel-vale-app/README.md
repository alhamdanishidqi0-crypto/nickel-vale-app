# Simulasi Ekonomi Nikel PT Vale Indonesia

## Jalankan Lokal
pip install -r requirements.txt
streamlit run app.py
