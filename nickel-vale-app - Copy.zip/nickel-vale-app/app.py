import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px

st.set_page_config(
    page_title="Simulasi Nikel PT Vale Indonesia",
    page_icon="⛏️",
    layout="wide"
)

st.title("⛏️ Simulasi Ekonomi Nikel PT Vale Indonesia")

st.markdown("""
Web simulasi ini digunakan untuk menganalisis:
- Harga nikel
- Tingkat diskonto
- Biaya produksi
- Marginal User Cost (MUC)
- Cadangan sumber daya

Terhadap:
- Produksi nikel
- Keuntungan perusahaan
- Umur cadangan
- Keberlanjutan sumber daya alam
""")

st.sidebar.header("Parameter Simulasi")

harga_nikel = st.sidebar.slider(
    "Harga Nikel (USD/ton)",
    10000,
    40000,
    22000,
    1000
)

biaya_produksi = st.sidebar.slider(
    "Biaya Produksi (USD/ton)",
    5000,
    20000,
    9000,
    500
)

muc = st.sidebar.slider(
    "Marginal User Cost",
    100,
    5000,
    1200,
    100
)

rate_diskonto = st.sidebar.slider(
    "Tingkat Diskonto (%)",
    1,
    20,
    8
)

cadangan_awal = st.sidebar.slider(
    "Cadangan Awal Nikel (ton)",
    1000000,
    100000000,
    50000000,
    1000000
)

produksi = (harga_nikel - biaya_produksi - muc) * 12

if produksi < 0:
    produksi = 0

keuntungan = (harga_nikel - biaya_produksi - muc) * produksi

umur_tambang = cadangan_awal / (produksi + 1)

col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "Produksi Tahunan",
    f"{produksi:,.0f} ton"
)

col2.metric(
    "Cadangan Nikel",
    f"{cadangan_awal:,.0f} ton"
)

col3.metric(
    "Umur Tambang",
    f"{umur_tambang:,.1f} tahun"
)

col4.metric(
    "Keuntungan",
    f"USD {keuntungan:,.0f}"
)

list_tahun = []
list_cadangan = []
list_keuntungan = []

cadangan = cadangan_awal

for tahun in range(1, 21):
    cadangan -= produksi

    if cadangan < 0:
        cadangan = 0

    keuntungan_tahun = keuntungan / (1 + rate_diskonto/100) ** tahun

    list_tahun.append(tahun)
    list_cadangan.append(cadangan)
    list_keuntungan.append(keuntungan_tahun)

df = pd.DataFrame({
    "Tahun": list_tahun,
    "Sisa Cadangan": list_cadangan,
    "Keuntungan Diskonto": list_keuntungan
})

st.header("📈 Grafik Sisa Cadangan")

fig1 = px.line(
    df,
    x="Tahun",
    y="Sisa Cadangan",
    markers=True,
    title="Penurunan Cadangan Nikel"
)

st.plotly_chart(fig1, use_container_width=True)

st.header("💰 Grafik Keuntungan")

fig2 = px.bar(
    df,
    x="Tahun",
    y="Keuntungan Diskonto",
    title="Keuntungan Setelah Diskonto"
)

st.plotly_chart(fig2, use_container_width=True)

st.header("📊 Analisis Ekonomi")

if harga_nikel > 30000:
    st.success(
        "Harga nikel tinggi meningkatkan produksi dan keuntungan perusahaan."
    )

if rate_diskonto > 12:
    st.warning(
        "Tingkat diskonto tinggi menyebabkan eksploitasi sumber daya lebih cepat."
    )

if muc > 3000:
    st.info(
        "MUC tinggi menunjukkan pentingnya konservasi sumber daya alam."
    )

st.header("📋 Data Simulasi")

st.dataframe(df, use_container_width=True)

st.markdown("---")

st.caption("Simulasi Ekonomi Sumber Daya Alam dan Lingkungan - PT Vale Indonesia")
